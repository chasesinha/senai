<?php
session_start();
include 'db.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$id = $_SESSION['usuario_id'];
$res = $conn->query("SELECT * FROM usuarios WHERE id=$id")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Perfil do Usuário - NEW WAY</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Montserrat', sans-serif;
            height: 100vh;
            overflow: hidden;
            color: #111;
        }

        /* Vídeo de fundo */
        .bg-video {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        .bg-video iframe {
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.35;
            pointer-events: none;
        }

        /* Cabeçalho com a marca */
        header {
            position: fixed;
            top: 0;
            width: 100%;
            text-align: center;
            padding: 25px 0;
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(6px);
            font-weight: 700;
            font-size: 26px;
            letter-spacing: 5px;
            color: #000;
            z-index: 2;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        /* Faixa central translúcida */
        .perfil-container {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 550px;
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            z-index: 1;
        }

        .perfil-container h2 {
            font-weight: 700;
            font-size: 28px;
            letter-spacing: 1px;
            margin-bottom: 40px;
        }

        .perfil-container p {
            font-size: 18px;
            margin: 12px 0;
        }

        a {
            display: inline-block;
            margin-top: 40px;
            text-decoration: none;
            padding: 12px 30px;
            border-radius: 8px;
            background: #000;
            color: #fff;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        a:hover {
            background: #fff;
            color: #000;
            border: 1px solid #000;
            transform: translateY(-3px);
        }
    </style>
</head>
<body>

<!-- Vídeo de fundo -->
<div class="bg-video">
    <iframe
        src="https://www.youtube.com/embed/m1iTy0zJ8dU?si=4zQbKwac_oWWSL69&autoplay=1&mute=1&controls=0&loop=1&playlist=m1iTy0zJ8dU&start=10"
        frameborder="0"
        allow="autoplay; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen>
    </iframe>
</div>

<!-- Cabeçalho -->
<header>NEW WAY</header>

<!-- Faixa de perfil -->
<div class="perfil-container">
    <h2>Perfil do Usuário</h2>
    <p><strong>Nome:</strong> <?php echo htmlspecialchars($res['nome']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($res['email']); ?></p>

    <a href="index.php">Voltar à Loja</a>
</div>

</body>
</html>
