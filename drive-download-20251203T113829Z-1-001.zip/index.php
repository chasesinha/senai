<?php
session_start();
include 'db.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$produtos = $conn->query("SELECT * FROM produtos");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Senaliaga - Loja de Grife</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
            color: #111;
        }

        /* ===== VÍDEO DE FUNDO ===== */
        .bg-video {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        .bg-video iframe {
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.99; /* Transparência */
            pointer-events: none;
            filter: blur(1px);
        }

        /* ===== OVERLAY SUAVE ===== */
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(245, 245, 245, 0.4);
            z-index: -1;
            backdrop-filter: blur(2px);
        }

        /* ===== CABEÇALHO ===== */
        header {
            background: rgba(255, 255, 255, 0.85);
            border-bottom: 2px dotted #999;
            padding: 15px 40px;
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: space-between;
            backdrop-filter: blur(10px);
        }

        .logo {
            font-size: 26px;
            letter-spacing: 5px;
            font-weight: 700;
        }

        .bemvindo {
            flex: 1;
            text-align: center;
            font-size: 16px;
            font-weight: 600;
        }

        .menu-direito {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .menu-direito img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            object-fit: cover;
        }

        .menu-direito a {
            text-decoration: none;
            color: black;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .menu-direito a:hover {
            color: #666;
        }

        /* ===== PRODUTOS ===== */
        .container {
            padding: 60px 40px;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 25px;
            justify-items: center;
        }

        .produto {
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid #ccc;
            border-radius: 10px;
            width: 90%;
            max-width: 230px;
            text-align: center;
            padding: 15px;
            opacity: 0;
            transform: translateY(30px);
            transition: opacity 0.6s ease, transform 0.6s ease, box-shadow 0.3s ease;
            backdrop-filter: blur(6px);
        }

        .produto.show {
            opacity: 1;
            transform: translateY(0);
            box-shadow: 0 10px 20px rgba(0,0,0,0.15);
        }

        .produto:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 30px rgba(0,0,0,0.25);
        }

        .produto img {
            max-width: 100%;
            max-height: 160px;
            object-fit: contain;
            border-radius: 6px;
        }

        .produto b {
            display: block;
            margin-top: 10px;
            font-size: 15px;
        }

        .produto p {
            margin: 5px 0;
            font-size: 14px;
            color: #333;
        }

        .produto a {
            display: inline-block;
            margin-top: 10px;
            text-decoration: none;
            color: black;
            border: 1px solid black;
            padding: 6px 12px;
            transition: all 0.3s ease;
            border-radius: 4px;
        }

        .produto a:hover {
            background: black;
            color: white;
        }

        /* ===== RESPONSIVIDADE ===== */
        @media (max-width: 1000px) {
            .container {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {
            .container {
                grid-template-columns: 1fr;
            }

            .bemvindo {
                display: none;
            }
        }
    </style>
</head>
<body>

    <!-- Vídeo de fundo -->
    <div class="bg-video">
        <iframe
            src="https://www.youtube.com/embed/m1iTy0zJ8dU?si=4zQbKwac_oWWSL69&autoplay=1&mute=1&controls=0&loop=1&playlist=m1iTy0zJ8dU&start=10"
            frameborder="0"
            allow="autoplay; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen>
        </iframe>
    </div>
    <div class="overlay"></div>

    <!-- Cabeçalho -->
    <header>
        <div class="logo">NEW WAY</div>

        <div class="bemvindo">
        </div>

        <div class="menu-direito">
            <a href="perfil.php">
                <img src="https://i.pinimg.com/736x/37/57/5a/37575a213755cad83bd408908623ba22.jpg" alt="Perfil">
            </a>
            <a href="runway.php">RUNWAY</a>
            <a href="carrinho.php">
                <img src="https://i.pinimg.com/1200x/7f/24/92/7f249252404646c08d90976505cb6937.jpg" alt="Carrinho">
            </a>
            <a href="logout.php">SAIR</a>
        </div>
    </header>

    <!-- Produtos -->
    <div class="container" id="produtos-container">
        <?php while($p = $produtos->fetch_assoc()) { ?>
            <div class="produto">
                <img src="<?php echo htmlspecialchars($p['imagem']); ?>" alt="<?php echo htmlspecialchars($p['nome']); ?>">
                <b><?php echo htmlspecialchars($p['nome']); ?></b>
                <p>R$ <?php echo number_format($p['preco'], 2, ',', '.'); ?></p>
                <a href="adicionar_carrinho.php?id=<?php echo $p['id']; ?>">Adicionar</a>
            </div>
        <?php } ?>
    </div>

    <script>
        // Animação de entrada suave
        document.addEventListener('DOMContentLoaded', function() {
            const produtos = document.querySelectorAll('.produto');
            produtos.forEach((el, i) => {
                setTimeout(() => el.classList.add('show'), i * 100);
            });
        });
    </script>

</body>
</html>

