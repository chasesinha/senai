<?php
session_start();
$nome = $_SESSION['nome'] ?? 'Cliente';
$endereco = $_SESSION['endereco'] ?? 'Endereço não informado';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Pedido Confirmado - New Way</title>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    html, body {
        height: 100%;
        overflow: hidden;
    }

    /* Fundo com vídeo */
    .video-background {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        z-index: -1;
        filter: blur(10px) brightness(0.7);
    }

    .video-background iframe {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 120%;
        height: 120%;
        transform: translate(-50%, -50%);
        pointer-events: none;
        opacity: 0.7;
    }

    /* Container principal */
    .container {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 450px;
        background: rgba(255, 255, 255, 0.65);
        backdrop-filter: blur(20px);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        box-shadow: 0 0 25px rgba(0,0,0,0.2);
        animation: fadeIn 1.2s ease forwards;
        opacity: 0;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateX(-50%) translateY(30px); }
        to { opacity: 1; transform: translateX(-50%) translateY(0); }
    }

    /* Logo */
    h1 {
        position: absolute;
        top: 100px;
        font-size: 30px;
        letter-spacing: 6px;
        color: #000;
        font-weight: 600;
    }

    /* Check verde animado */
    .checkmark {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 4px solid #4CAF50;
        animation: pulse 1.5s ease infinite;
        margin-bottom: 20px;
    }

    @keyframes pulse {
        0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(76, 175, 80, 0.6); }
        70% { transform: scale(1.05); box-shadow: 0 0 0 10px rgba(76, 175, 80, 0); }
        100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(76, 175, 80, 0); }
    }

    .checkmark svg {
        width: 60px;
        height: 60px;
        stroke: #4CAF50;
        stroke-width: 5;
        fill: none;
        stroke-dasharray: 48;
        stroke-dashoffset: 48;
        animation: draw 1s ease forwards;
    }

    @keyframes draw {
        to { stroke-dashoffset: 0; }
    }

    h2 {
        font-size: 26px;
        color: #000;
        margin-bottom: 10px;
    }

    p {
        color: #333;
        font-size: 16px;
        margin-bottom: 30px;
        line-height: 1.4;
    }

    a {
        text-decoration: none;
        padding: 12px 25px;
        border-radius: 8px;
        background: #000;
        color: white;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    a:hover {
        background: white;
        color: black;
        transform: translateY(-3px);
    }
</style>
</head>
<body>

<!-- Fundo com vídeo -->
<div class="video-background">
    <iframe src="https://www.youtube.com/embed/m1iTy0zJ8dU?si=4zQbKwac_oWWSL69&controls=0&start=10&autoplay=1&mute=1&loop=1&playlist=m1iTy0zJ8dU"
    title="YouTube video player" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>

<!-- Container com mensagem -->
<div class="container">
    <h1>NEW WAY</h1>

    <div class="checkmark">
        <svg viewBox="0 0 52 52">
            <path d="M14 27 l8 8 16 -16" />
        </svg>
    </div>

    <h2>Pedido Finalizado!</h2>
    <p>Obrigado pela compra, <strong><?= htmlspecialchars($nome) ?></strong>!<br>
    Seu pedido será enviado para:<br><strong><?= htmlspecialchars($endereco) ?></strong></p>

    <a href="index.php">Voltar à Loja</a>
</div>

</body>
</html>
