<?php
include 'db.php';
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO usuarios (nome, email, senha) VALUES ('$nome', '$email', '$senha')";
    if ($conn->query($sql)) {
        header('Location: login.php');
        exit();
    } else {
        $erro = "Erro ao cadastrar: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Cadastro - New Way</title>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    html, body {
        height: 100%;
        overflow: hidden;
    }

    /* Fundo com vídeo do YouTube */
    .video-background {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        z-index: -1;
        filter: blur(10px) brightness(0.7);
    }

    .video-background iframe {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 120%;
        height: 120%;
        transform: translate(-50%, -50%);
        pointer-events: none;
        opacity: 0.7;
    }

    /* Retângulo central vertical */
    .container {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 450px;
        background: rgba(255, 255, 255, 0.65);
        backdrop-filter: blur(20px);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        box-shadow: 0 0 25px rgba(0,0,0,0.2);
    }

    /* Título NEW WAY no topo */
    .container h1 {
        position: absolute;
        top: 100px;
        font-size: 30px;
        letter-spacing: 6px;
        color: #000;
        font-weight: 600;
        text-align: center;
    }

    /* Subtítulo Cadastrar */
    h2 {
        margin-top: 100px;
        color: #000;
        font-weight: 500;
        margin-bottom: 20px;
    }

    form {
        width: 80%;
        display: flex;
        flex-direction: column;
        gap: 15px;
        align-items: center;
    }

    input {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 8px;
        outline: none;
        font-size: 15px;
        background: #f2f2f2;
        color: #333;
    }

    button {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 8px;
        background: #000;
        color: white;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    button:hover {
        transform: translateY(-3px);
        background: white;
        color: black;
    }

    .erro {
        color: red;
        margin-top: 10px;
        font-size: 14px;
        text-align: center;
    }

    a {
        text-decoration: none;
        color: #000;
        font-size: 14px;
        margin-top: 10px;
        display: block;
    }
</style>
</head>
<body>

    <!-- Vídeo de fundo -->
    <div class="video-background">
        <iframe src="https://www.youtube.com/embed/m1iTy0zJ8dU?si=4zQbKwac_oWWSL69&controls=0&start=10&autoplay=1&mute=1&loop=1&playlist=m1iTy0zJ8dU"
        title="YouTube video player" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
    </div>

    <!-- Retângulo central -->
    <div class="container">
        <h1>NEW WAY</h1>
        <h2>Cadastrar</h2>

        <form method="POST">
            <input type="text" name="nome" placeholder="Nome completo" required>
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Cadastrar</button>
        </form>

        <?php if (!empty($erro)) echo "<div class='erro'>$erro</div>"; ?>

        <a href="login.php">Já tenho conta</a>
    </div>

</body>
</html>

