<?php
session_start();
include 'db.php';
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}
$id_produto = $_GET['id'];
$id_usuario = $_SESSION['usuario_id'];

$conn->query("INSERT INTO carrinho (usuario_id, produto_id) VALUES ($id_usuario, $id_produto)");
header('Location: carrinho.php');
?>
