<?php
session_start();
include 'db.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // segurança contra SQL injection
    $id_usuario = $_SESSION['usuario_id'];

    // Remove o item apenas se ele pertencer ao usuário logado
    $sql = "DELETE FROM carrinho WHERE id = $id AND usuario_id = $id_usuario";
    $conn->query($sql);
}

header('Location: carrinho.php');
exit();
?>
