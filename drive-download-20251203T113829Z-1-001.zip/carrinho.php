<?php
session_start();
include 'db.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$id_usuario = $_SESSION['usuario_id'];

// Busca produtos do carrinho com JOIN completo
$sql = "SELECT
            c.id AS carrinho_id,
            c.quantidade,
            p.nome,
            p.preco,
            p.imagem
        FROM carrinho c
        JOIN produtos p ON c.produto_id = p.id
        WHERE c.usuario_id = $id_usuario";
$res = $conn->query($sql);

$total = 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Seu Carrinho - NEW WAY</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #222;
        }

        header {
            background: #fff;
            padding: 25px 0;
            text-align: center;
            font-weight: 700;
            font-size: 24px;
            letter-spacing: 4px;
            border-bottom: 1px dotted #bbb;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background: #fff;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }

        h2 {
            text-align: center;
            margin-bottom: 40px;
            font-weight: 700;
            letter-spacing: 1px;
        }

        .produto {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
        }

        .produto:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.08);
        }

        .produto-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .produto img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 8px;
        }

        .produto-nome {
            font-weight: 600;
            font-size: 16px;
            color: #333;
        }

        .produto-preco {
            font-size: 15px;
            color: #444;
        }

        .quantidade {
            font-size: 14px;
            color: #666;
        }

        .subtotal {
            font-weight: 600;
            color: #000;
        }

        .btn {
            text-decoration: none;
            background: #fff;
            color: #000;
            padding: 10px 20px;
            border-radius: 8px;
            border: 1px solid #000;
            font-weight: 600;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: #000;
            color: #fff;
            transform: translateY(-3px);
        }

        .remover {
            background: #fff;
            border: 1px solid crimson;
            color: crimson;
        }

        .remover:hover {
            background: crimson;
            color: white;
        }

        .total {
            text-align: right;
            font-size: 18px;
            margin-top: 30px;
            font-weight: 600;
        }

        .botoes {
            text-align: center;
            margin-top: 40px;
        }

        .botoes a {
            margin: 0 10px;
        }

        .vazio {
            text-align: center;
            padding: 60px 0;
            color: #555;
            font-size: 18px;
        }

        .valor {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 6px;
        }
    </style>
</head>
<body>

<header>
    NEW WAY
</header>

<div class="container">
    <h2>Seu Carrinho de Compras</h2>

    <?php if ($res->num_rows > 0) { ?>
        <?php while ($c = $res->fetch_assoc()) {
            $subtotal = $c['preco'] * ($c['quantidade'] ?? 1);
            $total += $subtotal;
        ?>
            <div class="produto">
                <div class="produto-info">
                    <div>
                        <div class="produto-nome"><?php echo htmlspecialchars($c['nome']); ?></div>
                        <div class="produto-preco">R$ <?php echo number_format($c['preco'], 2, ',', '.'); ?></div>
                        <div class="quantidade">Quantidade: <?php echo $c['quantidade'] ?? 1; ?></div>
                    </div>
                </div>

                <div class="valor">
                    <div class="subtotal">Subtotal: R$ <?php echo number_format($subtotal, 2, ',', '.'); ?></div>
                    <a class="btn remover" href="remover_item.php?id=<?php echo $c['carrinho_id']; ?>">Remover</a>
                </div>
            </div>
        <?php } ?>

        <div class="total">Total: R$ <?php echo number_format($total, 2, ',', '.'); ?></div>

        <div class="botoes">
            <a class="btn" href="index.php">Continuar comprando</a>
            <a class="btn" href="finalizar.php">Finalizar compra</a>
        </div>

    <?php } else { ?>
        <div class="vazio">
            <p>Seu carrinho está vazio 😔</p>
            <a class="btn" href="index.php">🛒 Voltar à loja</a>
        </div>
    <?php } ?>
</div>

</body>
</html>
